<?php
echo "<table style='font-family: Arial,sans-serif; font-size: 80%;";
echo "width: 100%;'>";
echo "<tr>";
echo "<td style='width: 50%;'>";
echo "First Name:";
echo "</td >";
echo "<td style='width: 50%'>";
echo $_POST["fname"];
echo "</td>";
echo "</tr>";
echo "</table > ";
?>

