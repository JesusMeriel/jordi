<?php
$bobsmovierate = 5;
$joesmovierate = 7;
$grahamsmovierate = 2;
$zabbysmovierate = 1;
$avgmovierate=($bobsmovierate+$joesmovierate+$grahamsmovierate+$zabbysmovierate)/4;
echo "The average movie rating for this movie is: ";
echo $avgmovierate;
?>
